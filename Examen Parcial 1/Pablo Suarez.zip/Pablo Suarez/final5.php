<?php
for ($i=0; $i<1;$i++)
    echo "Calidad 5 Estrellas!"."<br>";
    echo "<br>";
?>