<?php
for ($i=0; $i<3;$i++)
    echo "3 es el numero magico"."<br>";

?>