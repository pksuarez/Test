<?php
    for ($i=0; $i<1;$i++)
        echo "Numero 1 a la cabeza";
?>