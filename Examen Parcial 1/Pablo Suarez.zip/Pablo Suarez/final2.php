<?php
for ($i=0; $i<2;$i++)
    echo "2 cabezas piensan mejor que 1!"."<br>";

?>