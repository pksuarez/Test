<?php
for ($i=0; $i<4;$i++)
    echo "4x4 a la cabeza del peloton"."<br>";

?>